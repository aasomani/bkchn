package params

import "github.com/ethereum/go-ethereum/common"

var (
	QuorumVotingContractAddr = common.Address{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 32}
)
